import {makeAutoObservable} from "mobx";

export default class DeviceStore {

    constructor(){
        this._types = [
            {id:1, name: 'Холодильники'},
            {id:2, name: 'Телефоны'},
        ]
        this._brands = [
            {id:1 , name: "Samsung"},
            {id:2 , name: "Apple"},
        ]
        this._devices =[
            {id:1 , name: "Iphone 12 pro", price: 25000, rating: 5, img : 'https://cdn-st1.rtr-vesti.ru/vh/pictures/xw/304/980/3.jpg'},
            {id:2 , name: "Iphone 13 pro", price: 35000, rating: 5, img : 'https://cdn-st1.rtr-vesti.ru/vh/pictures/xw/304/980/3.jpg'},
            {id:3 , name: "Iphone 14 pro", price: 45000, rating: 5, img : 'https://cdn-st1.rtr-vesti.ru/vh/pictures/xw/304/980/3.jpg'},
            {id:4 , name: "Iphone 15 pro", price: 55000, rating: 5, img : 'https://cdn-st1.rtr-vesti.ru/vh/pictures/xw/304/980/3.jpg'},
        ]
        makeAutoObservable(this)
    }

    setTypes(types){
        this._types = types
    }

    setBrands(brands){
        this._brands = brands
    }

    setDevice(device){
        this._device = device
    }
    get types(){
        return this._types
    }
    get brands(){
        return this._brands
    }
    get device(){
        return this._device
    }

}