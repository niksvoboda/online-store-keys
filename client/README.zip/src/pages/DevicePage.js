import React from "react";
import {useParams } from "react-router-dom";

const DevicePage = () =>{
   const  link = useParams();
    return(
        <div>
            DevicePage {link.id}
        </div>
    )
}

export default DevicePage;