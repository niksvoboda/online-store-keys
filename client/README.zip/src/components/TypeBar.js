import React, { useContext } from "react";
import {observer} from "mobx-react-lite"
import { Context } from "../index";
import { ListGroup } from "react-bootstrap";

const TypeBar = observer( () =>{
    const device = useContext(Context)
    return(
      <ListGroup>
        <ListGroup.Item>1</ListGroup.Item>
        <ListGroup.Item>2</ListGroup.Item>
        <ListGroup.Item>3</ListGroup.Item>
        <ListGroup.Item>4</ListGroup.Item>
      </ListGroup>
    )
})

export default TypeBar;